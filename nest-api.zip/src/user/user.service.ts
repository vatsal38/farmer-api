import { Injectable } from '@nestjs/common';
import { UserRepository } from './user.repository';
import * as bcrypt from 'bcryptjs';
import { JwtService } from '@nestjs/jwt';
import { MailerService } from '@nestjs-modules/mailer';
import { v4 as uuidv4 } from 'uuid';
import { join } from 'path';

@Injectable()
export class UserService {
  constructor(
    private readonly userRepository: UserRepository,
    private readonly jwtService: JwtService,
    private readonly mailerService: MailerService,
  ) {}

  async sendOTP(
    username: string,
    email: string,
    firstName: string,
    lastName: string,
  ): Promise<void> {
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    const otpExpiration = new Date();
    otpExpiration.setMinutes(otpExpiration.getMinutes() + 10);

    await this.userRepository.saveOTP(
      username,
      otp,
      otpExpiration,
      firstName,
      lastName,
    );

    await this.mailerService.sendMail({
      to: email,
      subject: 'Your OTP Code',
      template: './otp', // The template file should be otp.hbs
      context: {
        otp,
      },
    });
  }

  async verifyOTP(username: string, otp: string): Promise<boolean> {
    const user = await this.userRepository.findByUsername(username);
    if (user && user.otp === otp && user.otpExpiration > new Date()) {
      await this.userRepository.markAsVerified(username);
      return true;
    }
    return false;
  }

  async completeSignup(
    username: string,
    password: string,
    otp: string,
    firstName: string,
    lastName: string,
  ): Promise<any> {
    console.log('username, otp::: ', username, otp);
    const isValid = await this.verifyOTP(username, otp);
    if (isValid) {
      const hashedPassword = await bcrypt.hash(password, 10);
      const user: any = await this.userRepository.createUser(
        username,
        hashedPassword,
        firstName,
        lastName,
      );
      const payload = { username: user.username, sub: user.id };
      const token = this.jwtService.sign(payload);
      return { user, token };
    }
    throw new Error('Invalid OTP');
  }

  async validateUser(username: string, password: string): Promise<any> {
    const user = await this.userRepository.findByUsername(username);
    if (
      user &&
      user.isVerified &&
      (await bcrypt.compare(password, user.password))
    ) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }

  async login(user: any) {
    const payload = { username: user.username, sub: user.id };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}

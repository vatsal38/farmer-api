export const jwtConstants = {
  secret: 'your_secret_key',
};

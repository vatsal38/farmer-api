import { Controller, Post, Body, Request, UseGuards } from '@nestjs/common';
import { UserService } from './user.service';
import { LocalAuthGuard } from './local-auth.guard';

@Controller('auth')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('signup')
  async signup(
    @Body()
    body: {
      username: string;
      password: string;
      email: string;
      firstName: string;
      lastName: string;
    },
  ) {
    const { username, password, email, firstName, lastName } = body;
    await this.userService.sendOTP(username, email, firstName, lastName);
    return { message: 'OTP sent to your email' };
  }

  @Post('verify-otp')
  async verifyOtp(
    @Body()
    body: {
      username: string;
      otp: string;
      password: string;
      firstName: string;
      lastName: string;
    },
  ) {
    const { username, otp, password, firstName, lastName } = body;
    return this.userService.completeSignup(
      username,
      password,
      otp,
      firstName,
      lastName,
    );
  }

  @UseGuards(LocalAuthGuard)
  @Post('login')
  async login(@Request() req) {
    return this.userService.login(req.user);
  }
}
